import "../styles/Loader.scss";
const Loader = () => (
  <>
    <p className="loader-text">Loading...</p>
  </>
);

export default Loader;
