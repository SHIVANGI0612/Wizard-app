export const Error_Messages = {
  CONTEXT_ERROR: "Context not in provider.",
  RECORD_NOT_FOUND: "No record found.",
  SOMETHING_WRONG: "Oops! Something went wrong.",
};

export const fetchConfig = {
  URL: "https://wizard-world-api.herokuapp.com/elixirs",
};
